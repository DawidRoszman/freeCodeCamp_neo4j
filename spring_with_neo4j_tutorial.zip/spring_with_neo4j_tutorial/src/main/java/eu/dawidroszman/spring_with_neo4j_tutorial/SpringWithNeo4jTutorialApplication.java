package eu.dawidroszman.spring_with_neo4j_tutorial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringWithNeo4jTutorialApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringWithNeo4jTutorialApplication.class, args);
	}

}
