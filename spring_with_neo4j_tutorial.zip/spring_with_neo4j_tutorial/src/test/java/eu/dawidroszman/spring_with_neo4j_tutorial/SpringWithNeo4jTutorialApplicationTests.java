package eu.dawidroszman.spring_with_neo4j_tutorial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringWithNeo4jTutorialApplicationTests {

	@Test
	void contextLoads() {
	}

}
